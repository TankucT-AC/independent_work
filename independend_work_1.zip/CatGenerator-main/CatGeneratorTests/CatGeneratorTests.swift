//
//  CatGeneratorTests.swift
//  CatGeneratorTests
//
//  Created by Ширапов Арсалан on 31.10.2024.
//

import Testing
@testable import CatGenerator

struct CatGeneratorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
